package com.example.guiaturisticaecuador;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.mapbox.geojson.Point;
import com.mapbox.maps.MapView;
import com.mapbox.maps.Style;
import com.mapbox.maps.plugin.annotation.AnnotationConfig;
import com.mapbox.maps.plugin.annotation.AnnotationManager;
import com.mapbox.maps.plugin.annotation.generated.PointAnnotation;
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationManager;
import com.mapbox.maps.plugin.annotation.generated.PointAnnotationOptions;

public class MapActivity extends AppCompatActivity {

    private MapView mapView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapView = findViewById(R.id.mapView);

        mapView.getMapboxMap().loadStyleUri(Style.MAPBOX_STREETS, style -> {
            // Agrega un marcador en una ubicación específica
            addAnnotationToMap();
        });
    }

    private void addAnnotationToMap() {
        AnnotationConfig annotationConfig = new AnnotationConfig("point", "default");
        AnnotationManager annotationManager = mapView.getAnnotationManager();
        PointAnnotationManager pointAnnotationManager = annotationManager.createPointAnnotationManager(annotationConfig);

        PointAnnotationOptions pointAnnotationOptions = new PointAnnotationOptions()
                .withPoint(Point.fromLngLat(-78.4678, -0.1807)) // Quito, Ecuador
                .withIconImage("mapbox-marker-icon-default")
                .withTextField("Quito");

        PointAnnotation pointAnnotation = pointAnnotationManager.create(pointAnnotationOptions);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    protected void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
}

